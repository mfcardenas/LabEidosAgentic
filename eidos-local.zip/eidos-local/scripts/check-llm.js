// Comprueba que el modelo local responde y devuelve JSON. Uso: npm run check-llm
import { config } from "../server/config.js";
import { health, chatJSON } from "../server/llm.js";

const L = config.llm;
console.log(`Proveedor: ${L.provider} · ${L.baseUrl}`);
console.log(`Intérprete: ${L.routerModel} (${L.routerReasoning || "por defecto"}) · Compositor: ${L.composerModel} (${L.composerReasoning || "por defecto"})\n`);

const h = await health();
if (!h.reachable) {
  console.log(`✗ No hay respuesta de ${L.baseUrl}.`);
  console.log(L.provider === "ollama" ? "  Abre la app de Ollama o ejecuta: ollama serve" : "  Arranca tu servidor compatible con OpenAI.");
  process.exit(1);
}
console.log("✓ El servidor responde");
if (h.missing.length) {
  console.log(`✗ Faltan modelos: ${h.missing.join(", ")}`);
  if (L.provider === "ollama") console.log(`  Ejecuta: ${h.missing.map(m => `ollama pull ${m}`).join(" && ")}`);
  process.exit(1);
}
console.log("✓ Modelos disponibles");

for (const [rol, model, reasoning] of [["Intérprete", L.routerModel, L.routerReasoning], ["Compositor", L.composerModel, L.composerReasoning]]) {
  process.stdout.write(`… Probando ${rol} (${model}) `);
  try {
    const { value, seconds } = await chatJSON({ model, reasoning, label: "check", prompt: 'Responde SOLO con este JSON, sin nada más: {"ok": true, "saludo": "hola desde Eidos"}' });
    console.log(`\r✓ ${rol} responde JSON en ${seconds.toFixed(1)} s: ${JSON.stringify(value)}`);
  } catch (e) {
    console.log(`\r✗ ${rol}: ${e.message}`);
    if (e.raw) console.log(`  Respuesta recibida: ${String(e.raw).slice(0, 300)}`);
    process.exit(1);
  }
  if (model === L.composerModel && L.routerModel === L.composerModel && reasoning === L.composerReasoning) break;
}
console.log("\nTodo listo. Arranca con: npm start");

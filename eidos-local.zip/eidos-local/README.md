# Eidos

Una app que no tiene pantallas programadas. Solo existen sus **especificaciones** (`specs/`) y un runtime. Cuando pides una pantalla, dos agentes con **gpt-oss en tu ordenador** la diseñan a partir de las specs, un validador determinista la revisa, se guarda como plantilla y se reutiliza.

El ejemplo es un CRUD de usuarios con una base de datos SQLite pequeña.

## Requisitos

- **Node.js 22.13 o superior** (recomendado Node 24 LTS). No hay dependencias: no hace falta `npm install`.
- **[Ollama](https://ollama.com)** con el modelo **gpt-oss:20b** (unos 14 GB de descarga; va bien con 16 GB de RAM o VRAM).
  También funciona con LM Studio o cualquier servidor compatible con la API de OpenAI (ver Configuración).

## Arrancar

```bash
ollama pull gpt-oss:20b     # una vez
npm run check-llm           # comprueba que el modelo responde y devuelve JSON
npm start
```

Abre **http://localhost:3000**. La primera vez verás «Esta pantalla todavía no existe»: pulsa *Generar con los agentes*. Después prueba con los chips o escribe cosas como:

- «editores inactivos»
- «alta de Marta en Producto como editora»
- «edita a Iker, pásalo a admin»
- «reparto de usuarios por departamento»

### Probar sin modelo

```bash
npm run demo
```

Arranca un modelo **simulado** con la misma API que Ollama. Las pantallas son fijas y algunas traen errores a propósito para que veas al Guardián corregirlos. Usa su propia base de datos (`data/demo.db`).

## Cómo funciona

```
Persona ─texto─▶ Intérprete (gpt-oss, esfuerzo bajo) ─intent─▶ Datos ─▶ Caché de pantallas
                                                                          │ no está
                                                                          ▼
                                     Renderizador ◀── Guardián ◀── Compositor (gpt-oss)
                                     (navegador)     (código)       genera la plantilla
```

| Pieza | Qué hace | IA |
|---|---|---|
| **Intérprete** | Convierte «solo los admins» en `user.list {filter:{rol:"admin"}}` | Sí |
| **Datos** | Filtra, calcula métricas, valida con las reglas de la spec y escribe en SQLite | No |
| **Caché** | Guarda una plantilla por intent y versión de las specs. Si existe, no se llama al modelo | No |
| **Compositor** | Diseña la pantalla con el catálogo de componentes. No ve datos reales: escribe enlaces como `{{item.nombre}}` | Sí |
| **Guardián** | Revisa la plantilla: quita componentes que no existen, deja un solo botón primario, impide borrados fuera de la confirmación, añade campos obligatorios. Si no puede arreglarla, pide una corrección (una sola vez) | No |
| **Renderizador** | Une plantilla y datos en el navegador. Solo sabe dibujar el catálogo | No |

Los agentes **nunca escriben datos**: los cambios solo ocurren cuando envías un formulario o confirmas una baja.

Una plantilla sirve para cualquier dato: «detalle de Ana» y «detalle de Luis» comparten la misma. Si cambias una spec, cambia su versión y las plantillas viejas dejan de usarse.

## Cambiar la app

Todo lo que define la app está en `specs/`. El servidor las recarga solo: edita, guarda y recarga el navegador.

- **`app.spec.json`**: entidades (campos, reglas, métricas), intents, flujos y sugerencias.
- **`design.spec.json`**: tono y reglas de composición.
- **`catalog.spec.json`**: los componentes y acciones permitidos.

Ejemplo: añade un campo a `Usuario`:

```json
"telefono": { "tipo": "texto", "max": 20, "etiqueta": "Teléfono" }
```

Recarga, pulsa *Regenerar* (o deja que las plantillas se regeneren al pedirlas) y los formularios, el detalle y el Intérprete ya lo conocen.

Tipos de campo: `texto`, `email`, `enum` (con `valores`), `booleano`, `fecha`. Opciones: `requerido`, `min`, `max`, `unico`, `minusculas`, `porDefecto`, `soloLectura`, `auto: "alCrear"`.

Tipos de intent: `listado`, `detalle`, `alta`, `edicion`, `baja`, `libre`.

Las **reglas de negocio** que no caben en un campo se citan por id en la spec y se implementan en `server/rules.js` (ejemplo: `ultimoAdminActivo`).

Para **otra entidad**: añádela en `entidades`, crea sus intents y, si quieres datos de ejemplo, un `seeds/<Entidad>.json`. El runtime está escrito para varias entidades, pero solo se ha probado con `Usuario`.

## Configuración

Copia `.env.example` a `.env`. Lo más útil:

| Variable | Por defecto | Para qué |
|---|---|---|
| `LLM_PROVIDER` | `ollama` | `ollama` (API nativa) u `openai` (LM Studio, llama.cpp, vLLM…) |
| `LLM_BASE_URL` | `http://localhost:11434` | Para LM Studio: `http://localhost:1234/v1` |
| `ROUTER_MODEL` / `COMPOSER_MODEL` | `gpt-oss:20b` | Puedes usar `gpt-oss:120b` para el Compositor si tu máquina puede |
| `ROUTER_REASONING` / `COMPOSER_REASONING` | `low` / `medium` | Esfuerzo de razonamiento de gpt-oss |
| `LLM_NUM_CTX` | `16384` | Contexto en Ollama. El prompt del Compositor ronda 4-5k tokens: con menos se corta sin avisar |
| `LLM_TIMEOUT_MS` | `600000` | Tiempo máximo por llamada |
| `LOG_PROMPTS` | `false` | Guarda cada prompt y respuesta en `data/logs/` |

## Consejos con gpt-oss en local

- La primera pantalla de cada tipo tarda lo que tarde tu máquina (de segundos a un par de minutos en CPU). Después sale de la caché al instante.
- Si el Compositor devuelve plantillas pobres, sube `COMPOSER_REASONING=high`. Si tarda demasiado, bájalo a `low`.
- Si ves «no devolvió un JSON válido», activa `LOG_PROMPTS=true` y mira la respuesta en `data/logs/`. Prueba también `LLM_JSON_MODE=true`.
- Con LM Studio, carga el modelo antes y usa su nombre exacto en `ROUTER_MODEL` y `COMPOSER_MODEL`.

## Comandos

| Comando | Qué hace |
|---|---|
| `npm start` | Arranca Eidos con tu modelo local |
| `npm run check-llm` | Comprueba conexión, modelos y que responden JSON |
| `npm run demo` | Arranca con el modelo simulado |
| `npm run reset` | Borra la base de datos (vuelven los usuarios de ejemplo) |
| `npm run reset -- --pantallas` | Olvida solo las plantillas generadas |

## Estructura

```
specs/            La app: lo único que tocarías para cambiarla
seeds/            Datos de ejemplo por entidad
server/
  index.js        Servidor HTTP y API (respuestas en streaming NDJSON)
  runtime.js      El bucle que encadena a los agentes
  prompts.js      Prompts del Intérprete y del Compositor, construidos desde las specs
  llm.js          Conexión con gpt-oss (Ollama u OpenAI-compatible)
  guard.js        Guardián
  data.js         Datos: filtros, métricas, validación y escritura
  rules.js        Reglas de negocio citadas por la spec
  store.js        SQLite (node:sqlite)
  specs.js        Carga y versionado de las specs
public/           Shell y Renderizador del navegador
scripts/          check-llm, reset, demo y el modelo simulado
data/             Se crea al arrancar: eidos.db y logs
```

## API

- `GET /api/specs` · `GET /api/health` · `GET /api/screens` · `DELETE /api/screens/:clave`
- `POST /api/navigate` `{nav:{intent, params}, regenerate?, auto?}` → NDJSON con eventos `trace`, `working`, `result`, `missing`, `gone`, `error`
- `POST /api/ask` `{text, current?}` → igual, precedido por el Intérprete
- `POST /api/records/:Entidad` · `PUT /api/records/:Entidad/:id` · `DELETE /api/records/:Entidad/:id`

El servidor escucha solo en `127.0.0.1`. No tiene autenticación: es un prototipo para tu máquina.
